LocalBridge for Windows

1. Run setup_windows.bat.
2. Open https://ai-mongolia.netlify.app/#connect and pair this device.

Python is included. You do not need to install Python or change App Execution
Aliases. The installer runs LocalBridge in the background at
http://127.0.0.1:17833 and registers it to start automatically when you sign in.
