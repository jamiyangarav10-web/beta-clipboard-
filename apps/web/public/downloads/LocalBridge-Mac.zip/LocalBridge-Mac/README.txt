LocalBridge for macOS

1. Double-click setup_mac.command.
2. If macOS blocks it, Control-click the file, choose Open, then approve.
3. Open https://ai-mongolia.netlify.app/#connect and pair this device.

The installer runs LocalBridge in the background at http://127.0.0.1:17833.
