LocalBridge for Windows

1. Run setup_windows.bat.
2. Open https://localbridge-pairing-beta-163358.netlify.app/#connect and pair this device.

The installer runs LocalBridge in the background at http://127.0.0.1:17833 and
adds it to your Windows Startup folder.
